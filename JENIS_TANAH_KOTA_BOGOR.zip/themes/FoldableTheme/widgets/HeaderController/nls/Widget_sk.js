// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Ovl\u00e1da\u010d hlavi\u010dky",signin:"Prihl\u00e1si\u0165 sa",signout:"Odhl\u00e1si\u0165 sa",about:"Inform\u00e1cie",signInTo:"Prihl\u00e1si\u0165 sa do",cantSignOutTip:"T\u00e1to funkcia sa ned\u00e1 pou\u017ei\u0165 v re\u017eime n\u00e1h\u013eadu.",more:"viac",_localized:{}}});